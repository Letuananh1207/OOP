import java.util.Scanner;

public class DaysInMonth {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String monthInput;
        int year;
        
        while (true) {
            System.out.print("Nhập tháng ví dụ (e.g., January, Jan, 1): ");
            monthInput = scanner.nextLine().trim();
            System.out.print("Nhập năm ví dụ (e.g., 1999): ");
            String yearInput = scanner.nextLine().trim();
            
            // Validate year input
            if (!isValidYear(yearInput)) {
                System.out.println("Năm không hợp lệ.");
                continue;
            }
            year = Integer.parseInt(yearInput);
            
            // Get number of days in the month
            int days = getDaysInMonth(monthInput, year);
            if (days == -1) {
                System.out.println("Tháng không hợp lệ");
            } else {
                System.out.printf("Số ngày của tháng %s %d is: %d%n", monthInput, year, days);
                break;
            }
        }
        
        scanner.close();
    }

    private static boolean isValidYear(String yearInput) {
        if (yearInput.length() != 4) {
            return false;
        }
        for (char c : yearInput.toCharArray()) {
            if (!Character.isDigit(c)) {
                return false;
            }
        }
        return true;
    }

    private static int getDaysInMonth(String monthInput, int year) {
        switch (monthInput.toLowerCase()) {
            case "january":
            case "jan":
            case "jan.":
            case "1":
                return 31;
            case "february":
            case "feb":
            case "feb.":
            case "2":
                return isLeapYear(year) ? 29 : 28;
            case "march":
            case "mar":
            case "mar.":
            case "3":
                return 31;
            case "april":
            case "apr":
            case "apr.":
            case "4":
                return 30;
            case "may":
            case "may.":
            case "5":
                return 31;
            case "june":
            case "jun":
            case "jun.":
            case "6":
                return 30;
            case "july":
            case "jul":
            case "jul.":
            case "7":
                return 31;
            case "august":
            case "aug":
            case "aug.":
            case "8":
                return 31;
            case "september":
            case "sep":
            case "sep.":
            case "9":
                return 30;
            case "october":
            case "oct":
            case "oct.":
            case "10":
                return 31;
            case "november":
            case "nov":
            case "nov.":
            case "11":
                return 30;
            case "december":
            case "dec":
            case "dec.":
            case "12":
                return 31;
            default:
                return -1; // Invalid month
        }
    }

    private static boolean isLeapYear(int year) {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    }
}
