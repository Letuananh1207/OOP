import javax.swing.JOptionPane;

public class ChoosingOption {
    public static void main(String[] args) {
        // Hiển thị hộp thoại chỉ có nút Yes và No
        int option = JOptionPane.showConfirmDialog(
            null, 
            "Do you want to change to the first class ticket?", 
            "Confirm", 
            JOptionPane.YES_NO_OPTION
        );

        // Hiển thị kết quả lựa chọn
        JOptionPane.showMessageDialog(null, "You've chosen: " + (option == JOptionPane.YES_OPTION ? "Yes" : "No"));

        System.exit(0);
    }
}
